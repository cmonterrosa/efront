<?php

class module_mg_reports extends EFrontModule {


	private $id;		/* The report id */
	private $action;	/* The action you are performing on a report: $_GET['cat']: {view|edit} */
	private $command;	/* The operation you are performing on a report: $_GET['cmd']: {create|delete|clone} */
	private $smarty;

	public function __construct($defined_moduleBaseUrl, $defined_moduleFolder) {
		parent::__construct($defined_moduleBaseUrl, $defined_moduleFolder);

		$this->action = isset($_GET['act']) ? $_GET['act'] : null;
		$this->id = isset($_POST['report']) ? $_POST['report'] : 0;
		$this->id = isset($_GET['id']) ? $_GET['id'] : $this->id;
	}

	public function getName() {
		return _ADVANCEDMGREPORTS;
	}

	/**
	 * Get permitted roles for the module
	 * */
	public function getPermittedRoles() {
		return array('administrator', 'professor', 'student');
	}

	
	public function isLessonModule() {
		return false;
	}

	
	public function addScripts() {
		return array("scriptaculous/effects", "scriptaculous/controls", "includes/datepicker/datepicker");
	}
	
	/**
	 * Get JS scripts for the module
	 * */
	public function getModuleJS() {
		switch ($this->action) {
			case 'create':
				$javascript = $this -> moduleBaseDir . 'assets/create.js';
				break;			
			case 'edit':
				$javascript = $this->moduleBaseDir . 'assets/edit.js';
				break;
			case 'view':
			default:
				$javascript = $this->moduleBaseDir . 'assets/view.js';
				break;
		}
		return $javascript;
	}
	
	/**
	 * Get language file for the module
	 * */
	public function getLanguageFile($language) {
		$lang_dir = $this->moduleBaseDir . 'l10n/';
		$lang_file = $lang_dir . 'lang-' . $language . '.php';

		if (is_file($lang_file) == false) {
			$lang_file = $lang_dir . 'lang-english.php';
		}
		return $lang_file;
	}

	/**
	 * Get the appropriate Smarty tpl file for the module
	 * */
	public function getSmartyTpl() {
		$this->smarty = $this->getSmartyVar();
		$role = $this->getCurrentUser()->getType();

		switch ($this->action) {
			case 'create':
				require_once('controllers/create.php');
				$template = 'views/create.tpl';
				break;			
			case 'edit':
				require_once 'lib/MGReports_Report.php';
				$report = new MGReports_Report($this->id);
				require_once('controllers/edit.php');
				$template = 'views/edit.tpl';
				break;
			case 'delete':
				require_once('controllers/delete.php');
				$template = 'views/view.tpl';
				break;	
			case 'excel':
				require_once('Spreadsheet/Excel/Writer.php');
				
				// sending HTTP headers

				$workbook = new Spreadsheet_Excel_Writer(G_UPLOADPATH.$_SESSION['s_login']."/test.xls");
				// sending HTTP headers
				$workbook->send(G_UPLOADPATH.$_SESSION['s_login']."/test.xls");
				$worksheet =& $workbook->addWorksheet('Test');
				$worksheet->write(0, 0, 'hello world');
				$worksheet->close();
				// We still need to explicitly close the workbook
				$workbook->close();
				
				
				echo G_UPLOADPATH.$_SESSION['s_login']."/test.xls";
				exit;
				//$worksheet =& $workbook->addWorksheet('');
				
				//$workSheet->setInputEncoding('utf-8');
				//$workSheet->setTempDir(G_UPLOADPAH);
				//$workSheet->setVersion(8);
				
				
				//require_once('controllers/excel.php');
				break;
			case 'view':
			default:
				require_once('controllers/view.php');
				$template = 'views/view.tpl';
				break;
		}
		$this->smarty->assign("T_MODULE_BASEDIR", $this->moduleBaseDir);
		$this->smarty->assign("T_MODULE_BASELINK", $this->moduleBaseLink);
		$this->smarty->assign("T_MODULE_BASEURL", $this->moduleBaseUrl);
		
		return $this->moduleBaseDir . $template;
	}

	public function getNavigationLinks() {
		$smarty = $this -> getSmartyVar();
		 
		require_once($this->moduleBaseDir . '/lib/MGReports_Report.php');

		$breadcrumbs = array();

		$role = $this->getCurrentUser()->getType();

		$this->action = isset($_GET['act']) ? $_GET['act'] : null;
		$this->command = isset($_GET['cmd']) ? $_GET['cmd'] : null;

		$breadcrumbs[] = array(
				'title' => _HOME,
				'link' => $smarty->get_template_vars('T_HOME_LINK'));

		if ($lesson = $this->getCurrentLesson()) {
			$breadcrumbs[] = array(
					'title' => $lesson->lesson['name'],
					'link' => $_SERVER['PHP_SELF']);
		}

		$breadcrumbs[] = array(
				'title' => _ADVANCEDMGREPORTS,
				'link' => $this->moduleBaseUrl);

		if (MGReports_Report::isValid($this->id)) {

			$trainingReport = new MGReports_Report($this->id);

			$breadcrumbs[] = array(
					'title' => $trainingReport->getName(),
					'link' => $this->moduleBaseUrl . '&amp;id=' . $this->id);
		}

		return $breadcrumbs;
	}

	/**
	 * Get the center link on the administrator control panel of eFront
	 * */	
	public function getCenterLinkInfo() {
		$link = array(
			'title' => _ADVANCEDMGREPORTS,
			'image' => $this->moduleBaseDir . 'assets/images/logo32.png',
			'link' => $this->moduleBaseUrl
		);
		return $link;
	}

	public function getReportsLinkInfo() {
		$link = array(
				'title' => _ADVANCEDMGREPORTS,
				'image' => $this->moduleBaseDir . 'assets/images/logo32.png',
				'link' => $this->moduleBaseUrl);

		if ( ($this->getCurrentUser()->aspects['hcd'] && $this->getCurrentUser()->aspects['hcd']->isSupervisor()) || $_SESSION['s_type'] == 'professor') {
			return $link;
		} else {
			return false;
		}
	}

	/**
	 * Code to execute when a course is deleted
	 */	
	public function onDeleteCourse($courseId) {
		// Delete reports for this course
		eF_deleteTableData('module_time_reports_courses', 'courses_ID=' . $courseId);
		return false;
	}

	public function onUpgrade() {
		if (G_VERSIONTYPE == 'enterprise') { #cpp#ifdef ENTERPRISE
			eF_executeNew('CREATE TABLE IF NOT EXISTS `module_time_reports_branches` (`reports_ID` int(11) NOT NULL,`branches_ID` int(11) NOT NULL,PRIMARY KEY(`reports_ID`, `branches_ID`)) DEFAULT CHARSET=utf8;');
			return true;
		} #cpp#endif
	}

	/**
	 * Code to execute when the module is installed
	 * */
	public function onInstall() {
		global $_MG_REPORTS_INSTALL_QUERIES;	
		require_once('lib/schema.php');
		$result = true;
		// Create database tables for reports module
		foreach ($_MG_REPORTS_INSTALL_QUERIES as $index => $query) {	
			$result = $result && eF_executeNew($query);
		}
		return $result;
	}

	/**
	 * Code to execute when the module is uninstalled
	 * */
	public function onUninstall() {
		global $_MG_REPORTS_UNINSTALL_QUERIES;
		require_once('lib/schema.php');
		$result = true;
		// Drop all database tables for reports module
		foreach ($_MG_REPORTS_UNINSTALL_QUERIES as $index => $query) {
			$result = $result && eF_executeNew($query);
		}
		return $result;
	}

}

?>
