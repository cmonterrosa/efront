/*
document.observe("dom:loaded", function () {
    if( $('module-reports-select') ) {
        $('module-reports-select').observe('change', function (event) {
            event.findElement('form').submit();
        });
    }
}, false);
*/
function deleteMGReport(el, id) {
	parameters = {act:'delete', id:id, method: 'get'};
	var url    = location.toString();
	ajaxRequest(el, url, parameters, onDeleteMGReport);	
}
function onDeleteMGReport(el, response) {
	new Effect.Fade(el.up().up());
}

function runMGReport(el, id) {
	parameters = {act:'excel', id:id, method: 'get'};
	var url    = location.toString();
	ajaxRequest(el, url, parameters, onRunMGReport);	
}

function onRunMGReport(el, response) {
	alert(response);
	$('popup_frame').src = 'view_file.php?file='+response;
}