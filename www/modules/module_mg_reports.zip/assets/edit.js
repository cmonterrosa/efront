if ($('referal_user_autocomplete_div')) { 
	new Ajax.Autocompleter(
		"autocomplete_referal_user", 
		"referal_user_autocomplete_div", 
		"ask.php?ask_type=users",{
			paramName: "preffix", 
			afterUpdateElement : function (t, li) {$('referal_user_login').value = li.id;}, 
			indicator : "busy_referal_user"
		}
	); 
}

if ($('efront_recipient_autocomplete_div')) { 
	new Ajax.Autocompleter(
		"autocomplete_efront_recipient", 
		"efront_recipient_autocomplete_div", 
		"ask.php?ask_type=users",{
			paramName: "preffix", 
			afterUpdateElement : function (t, li) {$('efront_recipient_login').value = li.id;}, 
			indicator : "busy_efront_recipient"
		}
	); 
}

var dpicker = new DatePicker({
	relative : 'report_datepicker',
	dateFormat: [["yyyy", "mm", "dd"], "-" ],
	keepFieldEmpty : true
});	

