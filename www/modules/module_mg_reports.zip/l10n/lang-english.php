<?php

define('_ADVANCEDMGREPORTS', 'Advanced reports for Mentor Graphics');

define('_ADVANCEDMGREPORTS_NAME', 'Report name');

define('_ADVANCEDMGREPORTS_TYPE', 'Report type');
define('_ADVANCEDMGREPORTS_ALL_INSTRUCTED', 'All instructed by the referal user');
define('_ADVANCEDMGREPORTS_ALL_SUPERVISED', 'All supervised by the referal user');
define('_ADVANCEDMGREPORTS_ALL_SUPERVISED_AND_BRANCHES', 'All supervised by the referal user & sub-branches');
define('_ADVANCEDMGREPORTS_REFERAL_USER', 'Referal User');

define('_ADVANCEDMGREPORTS_EFRONT_RECIPIENT', 'eFront Recipient');
define('_ADVANCEDMGREPORTS_CUSTOM_EMAILS', 'Custom Emails');
define('_ADVANCEDMGREPORTS_CUSTOM_EMAILS_NOTE', 'Semicolon separated emails');

define('_ADVANCEDMGREPORTS_RUN_REPORT', 'Run report');

define('_ADVANCEDMGREPORTS_NOW', 'Now');
define('_ADVANCEDMGREPORTS_RUN_ON', 'Run on');
define('_ADVANCEDMGREPORTS_RUN_EVERY', 'Run every');
define('_ADVANCEDMGREPORTS_AND_REPEATY_EVERY', '...and repeat every');

define('_ADVANCEDMGREPORTS_RECIPIENTS_USERS', 'Users');



define('_ADVANCEDMGREPORTS_DAY', 'Day');
define('_ADVANCEDMGREPORTS_WEEK', 'Week');
define('_ADVANCEDMGREPORTS_MONTH', 'Month');
define('_ADVANCEDMGREPORTS_YEAR', 'Year');



define('_TRAININGREPORTS_GENERAL', 'General');
define('_TRAININGREPORTS_FIELDS', 'Fields');
define('_TRAININGREPORTS_DATES', 'Dates');
define('_TRAININGREPORTS_REGISTERED', 'Registration Date');
define('_TRAININGREPORTS_ALLCOMPLETED', 'All completed?');

define('_TRAININGREPORTS_ADDBRANCH', 'Add branch');
define('_TRAININGREPORTS_ADDCOURSE', 'Add course');
define('_TRAININGREPORTS_ADDFIELD', 'Add field');

define('_TRAININGREPORTS_STARTDATEAFTERENDDATE', 'From date is after End date');
define('_TRAININGREPORTS_INVALIDDATE', 'Date is not valid');
define('_TRAININGREPORTS_MAXCOLUMNSEXCEEDED', 'The report exceeds the max columns Excel can display.<br/>Try to limit the selected period or select a longer interval from the "Group by" field.');

define('_TRAININGREPORTS_SUCCESSFULLYCREATED', 'The report was created');
define('_TRAININGREPORTS_SUCCESSFULLYDELETED', 'The report was deleted');
define('_TRAININGREPORTS_SUCCESSFULLYCLONED', 'The report was cloned');
define('_TRAININGREPORTS_SUCCESSFULLYSAVED', 'The report was saved');

define('_TRAININGREPORTS_LEGENDCOMPLETED', 'Lessons that have been completed');
define('_TRAININGREPORTS_LEGENDINCOMPLETE', 'Lessons that have been started but NOT completed');
define('_TRAININGREPORTS_LEGENDOUTSIDE', 'Lessons that have NOT ben started');

define('_TRAININGREPORTS_STARTED', 'Started');
define('_TRAININGREPORTS_NOTSTARTED', 'Ξ�ΞΏt started');
define('_TRAININGREPORTS_ENDED', 'Completed');

?>
