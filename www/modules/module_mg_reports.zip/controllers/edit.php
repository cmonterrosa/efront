<?php

require_once($this->moduleBaseDir . '/lib/utilities.php');
require_once($this->moduleBaseDir . '/lib/MGReports_Report.php');


$report = new MGReports_Report($this->id);


$form = new HTML_QuickForm("create_mg_report_form", "post", $this->moduleBaseUrl . "&act=" . $this->action ."&id=" . $this->id , "", null, true);  //Build the form

$form -> addElement('text', 'name', _ADVANCEDMGREPORTS_NAME, 'class = "inputText"');                    //The lesson name, it is required and of type 'text'
$form->addRule('name', _THEFIELD .' "' . _ADVANCEDMGREPORTS_REPORTNAME.'" '._ISMANDATORY, 'required', null, 'client');

$form -> addElement('text', 'referal_user', _ADVANCEDMGREPORTS_REFERAL_USER, 'id = "autocomplete_referal_user" class = "inputText autoCompleteTextBox" ');
$form -> addRule('referal_user', _THEFIELD.' "'._ADVANCEDMGREPORTS_REFERAL_USER.'" '._ISMANDATORY, 'required', null, 'client');
$form -> addElement('hidden', 'referal_user_login', '' , 'id="referal_user_login"');

$form -> addElement('select', 'type', _ADVANCEDMGREPORTS_TYPE, array(_ADVANCEDMGREPORTS_ALL_INSTRUCTED => _ADVANCEDMGREPORTS_ALL_INSTRUCTED, _ADVANCEDMGREPORTS_ALL_SUPERVISED => _ADVANCEDMGREPORTS_ALL_SUPERVISED, _ADVANCEDMGREPORTS_ALL_SUPERVISED_AND_BRANCHES => _ADVANCEDMGREPORTS_ALL_SUPERVISED_AND_BRANCHES));
$form->addRule('type', _THEFIELD.' "'._ADVANCEDMGREPORTS_RECIPIENTS_USERS.'" '._ISMANDATORY, 'required', null, 'client');


$form -> addElement('text', 'efront_recipient', _ADVANCEDMGREPORTS_EFRONT_RECIPIENT, 'id = "autocomplete_efront_recipient" class = "inputText autoCompleteTextBox" ');
$form->addRule('efront_recipient', _THEFIELD.' "'._ADVANCEDMGREPORTS_EFRONT_RECIPIENT.'" '._ISMANDATORY, 'required', null, 'client');
$form -> addElement('hidden', 'efront_recipient_login', '' , 'id="efront_recipient_login"');

$form -> addElement('text', 'custom_emails', _ADVANCEDMGREPORTS_CUSTOM_EMAILS, 'class = "inputText"');

$form -> addElement('text', 'date', _ADVANCEDMGREPORTS_DATE, 'id="datepicker" class=" datepicker" maxlength="10" size="9"');
$form -> addRule('date', _ADVANCEDMGREPORTS_DATE, 'isValidDate');

$form -> addElement('submit', 'submit_report', _SUBMIT, 'class = "flatButton"');

$defaults = $report->getReport();
$defaults['custom_emails'] = implode("; ", $report->getCustomEmails());
$form->setDefaults($defaults);

$renderer = new HTML_QuickForm_Renderer_ArraySmarty($this->smarty);
$renderer -> setRequiredTemplate ('{$html}{if $required}&nbsp;<span class = "formRequired">*</span>{/if}');
$renderer->setErrorTemplate('{$html}{if $error}<div class = "formError">{$error}</div>{/if}');

$form -> setJsWarnings(_BEFOREJAVASCRIPTERROR, _AFTERJAVASCRIPTERROR);          //Set javascript error messages
$form -> setRequiredNote(_REQUIREDNOTE);
$form -> accept($renderer);                                                     //Assign this form to the renderer, so that corresponding template code is created

$this->smarty->assign('T_MGREPORT_FORM', $renderer -> toArray());
$this->smarty->assign('T_ADVANCEDMGREPORTS_RECIPIENTS_EMAILCUSTOMEMAIL', _ADVANCEDMGREPORTS_RECIPIENTS_EMAILCUSTOMEMAIL);

if ($form -> isSubmitted() && $form -> validate()) {
	$values = $form -> exportValues();

	$fields = array(
		'report_name' => $values['report_name'],
		'report_recipient' => $values['report_recipient'],
		'report_recipient_email' => $values['report_recipient_email'],
		'report_type' => $values['report_type'],
		'report_date' => date("Y-m-d",strtotime($values['report_date'])),
		'report_repeat' => $values['report_repeat'],
		'report_repeat_every' => ($values['report_repeat']) ? $values['report_repeat_every'] : ''
	);

	$result = eF_updateTableData('module_mg_reports', $fields, "id='".$this->id."'");
	pr($this->id);
	pr($fields);
	pr($result );
	
	//exit;
	
	eF_redirect($this->moduleBaseUrl);
}

?>
