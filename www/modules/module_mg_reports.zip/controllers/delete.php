<?php 
eF_deleteTableData("module_mg_reports", "id = '".$this->id."'");
?>