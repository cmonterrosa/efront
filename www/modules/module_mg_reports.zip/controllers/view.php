<?php

//require_once($this->moduleBaseDir . '/lib/utilities.php');
//require_once($this->moduleBaseDir . '/lib/TrainingReports_Report.php');

if (isset($_GET['ajax']) && $_GET['ajax'] == 'mgReportsTable') {
	 
	$reports_list = eF_getTableData('module_mg_reports');

	isset($_GET['limit']) ? $limit = $_GET['limit'] : $limit = G_DEFAULT_TABLE_SIZE;

	if (isset($_GET['sort'])) {
		isset($_GET['order']) ? $order = $_GET['order'] : $order = 'asc';
		$reports_list = eF_multiSort($reports_list, $_GET['sort'], $order);
	}

	if (isset($_GET['limit']) && eF_checkParameter($_GET['limit'], 'int')) {
		isset($_GET['offset']) && eF_checkParameter($_GET['offset'], 'int') ? $offset = $_GET['offset'] : $offset = 0;
		$reports_list = array_slice($reports_list, $offset, $limit);
	}

	$reports_list = eF_getTableData('module_mg_reports');
	pr($reports_list);
	$this -> smarty -> assign('T_MG_REPORTS_LIST', $reports_list);

	$sizeof_reports_list = sizeof($reports_db_entries);
	$this -> smarty -> assign("T_MG_REPORTS_LIST_SIZE", $sizeof_reports_list);

	
	$this->smarty->assign('T_MG_ADVANCEDMGREPORTS_MODULEBASEURL', $this->moduleBaseUrl);
	$this->smarty->assign('T_MG_ADVANCEDMGREPORTS_NAME', _ADVANCEDMGREPORTS_NAME);
	$this->smarty->assign('T_MG_ADVANCEDMGREPORTS_TYPE', _ADVANCEDMGREPORTS_TYPE);
	$this->smarty->assign('T_MG_ADVANCEDMGREPORTS_RUN_ON', _ADVANCEDMGREPORTS_RUN_ON);
	$this->smarty->assign('T_MG_ADVANCEDMGREPORTS_EVERY', _ADVANCEDMGREPORTS_RUN_EVERY); 
	

}?>
