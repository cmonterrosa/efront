<?php 
/*
`id`
`name`
`referal_user`
`type` 
`efront_recipient`
`custom_emails`
`date`
`repeat`
`repeat_every`
*/

$form = new HTML_QuickForm("create_mg_report_form", "post", $this->moduleBaseUrl . "&act=" . $this->action , "", null, true);  //Build the form

$form -> addElement('text', 'name', _ADVANCEDMGREPORTS_NAME, 'class = "inputText"');                    //The lesson name, it is required and of type 'text'
$form->addRule('name', _THEFIELD .' "' . _ADVANCEDMGREPORTS_REPORTNAME.'" '._ISMANDATORY, 'required', null, 'client');

$form -> addElement('text', 'referal_user', _ADVANCEDMGREPORTS_REFERAL_USER, 'id = "autocomplete_referal_user" class = "inputText autoCompleteTextBox" ');
$form -> addRule('referal_user', _THEFIELD.' "'._ADVANCEDMGREPORTS_REFERAL_USER.'" '._ISMANDATORY, 'required', null, 'client');
$form -> addElement('hidden', 'referal_user_login', '' , 'id="referal_user_login"');

$form -> addElement('select', 'type', _ADVANCEDMGREPORTS_TYPE, array(_ADVANCEDMGREPORTS_ALL_INSTRUCTED => _ADVANCEDMGREPORTS_ALL_INSTRUCTED, _ADVANCEDMGREPORTS_ALL_SUPERVISED => _ADVANCEDMGREPORTS_ALL_SUPERVISED, _ADVANCEDMGREPORTS_ALL_SUPERVISED_AND_BRANCHES => _ADVANCEDMGREPORTS_ALL_SUPERVISED_AND_BRANCHES));
$form->addRule('type', _THEFIELD.' "'._ADVANCEDMGREPORTS_RECIPIENTS_USERS.'" '._ISMANDATORY, 'required', null, 'client');


$form -> addElement('text', 'efront_recipient', _ADVANCEDMGREPORTS_EFRONT_RECIPIENT, 'id = "autocomplete_efront_recipient" class = "inputText autoCompleteTextBox" ');
$form->addRule('efront_recipient', _THEFIELD.' "'._ADVANCEDMGREPORTS_EFRONT_RECIPIENT.'" '._ISMANDATORY, 'required', null, 'client');
$form -> addElement('hidden', 'efront_recipient_login', '' , 'id="efront_recipient_login"');

$form -> addElement('text', 'custom_emails', _ADVANCEDMGREPORTS_CUSTOM_EMAILS, 'class = "inputText"');

$form -> addElement('text', 'date', _ADVANCEDMGREPORTS_DATE, 'id="datepicker" class=" datepicker" maxlength="10" size="9"');
$form -> addRule('date', _ADVANCEDMGREPORTS_DATE, 'isValidDate');

//$form -> addElement('radio', 'run', _ADVANCEDMGREPORTS_RUN_REPORT, 'id=""');

//$form -> addElement('radio', 'run', null, null, _ADVANCEDMGREPORTS_NOW,    'selected = "selected"');
//$form -> addElement('radio', 'run', null, null, _ADVANCEDMGREPORTS_ON, '');


//$form -> addElement('advcheckbox', 'repeat', _ADVANCEDMGREPORTS_REPEAT_EVERY, null,  'id="repeat" class = "inputCheckbox"', array(0, 1));
//$form -> addElement('select', 'repeat_every', _ADVANCEDMGREPORTS_AND_REPEATE_EVERY, array(_ADVANCEDMGREPORTS_DAY => _ADVANCEDMGREPORTS_DAY, _ADVANCEDMGREPORTS_WEEK => _ADVANCEDMGREPORTS_WEEK, _ADVANCEDMGREPORTS_MONTH => _ADVANCEDMGREPORTS_MONTH, _ADVANCEDMGREPORTS_YEAR => _ADVANCEDMGREPORTS_YEAR));

$form -> addElement('submit', 'submit_report', _SUBMIT, 'class = "flatButton"');

$renderer = new HTML_QuickForm_Renderer_ArraySmarty($this->smarty);
$renderer -> setRequiredTemplate ('{$html}{if $required}&nbsp;<span class = "formRequired">*</span>{/if}');
$renderer->setErrorTemplate('{$html}{if $error}<div class = "formError">{$error}</div>{/if}');

$form -> setJsWarnings(_BEFOREJAVASCRIPTERROR, _AFTERJAVASCRIPTERROR);          //Set javascript error messages
$form -> setRequiredNote(_REQUIREDNOTE);
$form -> accept($renderer);                                                     //Assign this form to the renderer, so that corresponding template code is created

$this->smarty->assign('T_MGREPORT_FORM', $renderer -> toArray());
$this->smarty->assign('T_ADVANCEDMGREPORTS_AND_REPEATY_EVERY', _ADVANCEDMGREPORTS_AND_REPEATY_EVERY);
$this->smarty->assign('T_ADVANCEDMGREPORTS_CUSTOM_EMAILS_NOTE', _ADVANCEDMGREPORTS_CUSTOM_EMAILS_NOTE);

if ($form -> isSubmitted() && $form -> validate()) {
	$values = $form -> exportValues();

	// trim custom emails
	$custom_emails = array();
	foreach (explode(";", $values['custom_emails']) as $custom_email){
		$custom_emails[] = trim($custom_email);
	}
	
	
	$fields = array(
		'name' => $values['name'],
		'referal_user' => $values['referal_user_login'],
		'type' => $values['type'],
		'efront_recipient' => $values['efront_recipient_login'],
		'custom_emails' => serialize($custom_emails),	
/*		'date' => '2013-07-23',
		'repeat' => '1',
		'repeat_every' => ($values['repeat_every']) ? $values['repeat_every'] : '1'*/
	);
	
	pr($fields);
	
	$result = eF_insertTableData('module_mg_reports', $fields);
		
	eF_redirect($this->moduleBaseUrl);
	
		
}


?>