<?php

/**
 * Array of install queries to be performed.
 * */
$_MG_REPORTS_INSTALL_QUERIES = array();
$_MG_REPORTS_INSTALL_QUERIES[] = '
	CREATE TABLE IF NOT EXISTS `module_mg_reports` (
		`id` int(11) NOT NULL AUTO_INCREMENT,
		`name` varchar(128) NOT NULL,
		`referal_user` varchar(128) NOT NULL,
		`type` varchar(128) NOT NULL,
		`efront_recipient` varchar(128) NOT NULL,
		`custom_emails` varchar(128) NOT NULL,		
		`date` date NULL,
		`repeat` int(10) NOT NULL,
		`repeat_every` varchar(128) NOT NULL,
		PRIMARY KEY (`id`)
	) DEFAULT CHARSET=utf8;
';
$_MG_REPORTS_INSTALL_QUERIES[] = '
    CREATE TABLE IF NOT EXISTS `module_mg_reports_fields` (
        `reports_ID` int(11) NOT NULL,
        `name` varchar(64) NOT NULL,
        `position` tinyint(3) unsigned NOT NULL,
        PRIMARY KEY(`reports_ID`, `name`, `position`)
    ) DEFAULT CHARSET=utf8;
';
/**
 * Array uninstall queries to be performed.
 * */
$_MG_REPORTS_UNINSTALL_QUERIES = array();
$_MG_REPORTS_UNINSTALL_QUERIES[] = '
		DROP TABLE IF EXISTS `module_mg_reports`
';

/************************************************************************************/

/* Install queries 
$_TIME_REPORTS_INSTALL_QUERIES = array();

$_TIME_REPORTS_INSTALL_QUERIES[] = '
    CREATE TABLE IF NOT EXISTS `module_time_reports` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(128) NOT NULL,
        `from_date` int(10) NOT NULL,
        `to_date` int(10) NOT NULL,
        `separated_by` varchar(16) NOT NULL,
        PRIMARY KEY (`id`)
    ) DEFAULT CHARSET=utf8;
';

$_TIME_REPORTS_INSTALL_QUERIES[] = '
    CREATE TABLE IF NOT EXISTS `module_time_reports_fields` (
        `reports_ID` int(11) NOT NULL,
        `name` varchar(64) NOT NULL,
        `position` tinyint(3) unsigned NOT NULL,
        PRIMARY KEY(`reports_ID`, `name`, `position`)
    ) DEFAULT CHARSET=utf8;
';

$_TIME_REPORTS_INSTALL_QUERIES[] = '
    CREATE TABLE IF NOT EXISTS `module_time_reports_courses` (
        `reports_ID` int(11) NOT NULL,
        `courses_ID` int(11) NOT NULL,
        `position` tinyint(3) NOT NULL,
        PRIMARY KEY(`reports_ID`, `courses_ID`, `position`)
    ) DEFAULT CHARSET=utf8;
';

if (G_VERSIONTYPE == 'enterprise') { #cpp#ifdef ENTERPRISE
$_TIME_REPORTS_INSTALL_QUERIES[] = '
    CREATE TABLE IF NOT EXISTS `module_time_reports_branches` (
        `reports_ID` int(11) NOT NULL,
        `branches_ID` int(11) NOT NULL,
        PRIMARY KEY(`reports_ID`, `branches_ID`)
    ) DEFAULT CHARSET=utf8;
';
} #cpp#endif

/* Uninstall queries 
$_TIME_REPORTS_UNINSTALL_QUERIES = array();

$_TIME_REPORTS_UNINSTALL_QUERIES[] = 'DROP TABLE IF EXISTS `module_time_reports`';
$_TIME_REPORTS_UNINSTALL_QUERIES[] = 'DROP TABLE IF EXISTS `module_time_reports_fields`';
$_TIME_REPORTS_UNINSTALL_QUERIES[] = 'DROP TABLE IF EXISTS `module_time_reports_courses`';
if (G_VERSIONTYPE == 'enterprise') { #cpp#ifdef ENTERPRISE
	$_TIME_REPORTS_UNINSTALL_QUERIES[] = 'DROP TABLE IF EXISTS `module_time_reports_branches`';
} #cpp#endif
*/
?>
