<?php 
/**
 * Represents a training report.
 */
class MGReports_Report {

	private $report = NULL;
	
	private $name = NULL;
	
	private $referal_user = NULL;
	private $type = NULL;
	
	private $efront_recipient = NULL;
	private $custom_emails = array();
	
	private $fields = array();
	
	/**
	 * Constructor
	 *
	 * @param integer $id The id of the report
	 */
	public function __construct($id = null) {
		if ($id != null) {
			$report = eF_getTableData('module_mg_reports', '*', 'id=' . $id);
			
			$this->report = $report[0];
			
			$this->name = $this->report['name'];
			
			$this->referal_user = EfrontUserFactory::factory ($this->report['referal_user']);
			$this->type = $this->report['type'];
			
			$this->efront_recipient = EfrontUserFactory::factory ($this->report['efront_recipient']);
			$this->custom_emails = unserialize($this->report['custom_emails']);
			
			//$results = eF_getTableDataFlat('module_time_reports_fields', 'name', 'reports_ID=' . $id, 'position');
			//if (sizeof($results) > 0) {
			//	$this->fields = $results['name'];
			//}			
		}
	}
	
	/**
	 * Returns wheather a report is valid or not.
	 *
	 * @param integer $id The id of the report
	 * @return boolean true if valid false otherwise
	 */
	public static function isValid($id) {
		$isValid = false;
	
		if (is_numeric($id)) {
			$reports = eF_getTableData('module_mg_reports', 'id', 'id=' . $id);
			$isValid = (count($reports) == 1);
		}
	
		return $isValid;
	}
	
	/**
	 * Returns the basic data of a report.
	 * @return array
	 */
	public function getReport() {
		return $this->report;
	}
	
	/**
	 * Returns the name of the report
	 *
	 * @return string The name of the report
	 */
	public function getName() {
		return $this->name;
	}

	/**
	 * Returns the referal user of the report
	 *
	 * @return EfrontUser The referal user of the report
	 */
	public function getReferalUser() {
		return $this->referal_user;
	}
	
	/**
	 * Returns the type of the report
	 *
	 * @return string The type of the report
	 */
	public function getType() {
		return $this->type;
	}
	
	
	/**
	 * Returns the efront recipient of the report
	 *
	 * @return EfrontUser The efront recipient of the report
	 */
	
	public function getEfrontRecipient() {
		return $this->efront_recipient;
	}

	/**
	 * Returns the custom emails of the report
	 *
	 * @return array the custom emails of the report
	 */
	public function getCustomEmails() {
		return $this->custom_emails;
		
	}

	
	/**
	 * Returns the fields of the report
	 *
	 * @return array The fields of the report
	 */
	public function getFields() {
		return $this->fields;
	}
	
	/**
	 * Returns the avaible fields to select from for a report.
	 *
	 * @return array
	 */
	public static function getFieldsOptions() {
	
		$standardOptions = array(
				'name' => _NAME,
				'surname' => _SURNAME,
				'email' => _EMAIL,
				'login' => _LOGIN,
				'office' => _OFFICE,
				'city' => _CITY,
				'timestamp' => _TRAININGREPORTS_REGISTERED,
				'completed' => _TRAININGREPORTS_ALLCOMPLETED,
				'last_login' => _LASTLOGIN);
	
		if (G_VERSIONTYPE == 'enterprise') { #cpp#ifdef ENTERPRISE
			$standardOptions['branch'] = _BRANCH;
		} #cpp#endif
	
		$results = eF_getTableDataFlat('user_profile', 'name, description', 'type !="branchinfo" and type != "groupinfo"');
	
        if (sizeof($results) > 0) {
	        $extendedOptions = array_combine($results['name'], $results['description']);
	        $fieldOptions = array_merge($standardOptions, $extendedOptions);
		} else {
		$fieldOptions = $standardOptions;
	}
	
		return $fieldOptions;
	}

	public function getUserData() {
		
		//get users in report...
		
		$referal_user = $this->getReferalUser();
		
		// primary group of users
		switch($this->getType()){
			case _ADVANCEDMGREPORTS_ALLINSTRUCTED:
					break;
			case _ADVANCEDMGREPORTS_ALLSUPERVISED:
				break;
			case _ADVANCEDMGREPORTS_ALLSUPERVISEDBRANCHES:
				break;
		}	
		// single users
		// get each single user
		

		//foreach user get
		// name, last name, email, last loggin, active loggins since last report
		// - user courses
		// - users progress in courses
		
	}
	
	public function getUsers() {

		switch(TRUE){
			case 'All intructed by the referal user':
				break;
			case 'All supervised by the referal super':
				break;
			case 'All supervised by the referal user + sub branches':
				break;
		}
		
	}
	
}
?>