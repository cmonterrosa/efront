<?php

global$_TIME_REPORTS_EXCEL_FORMATS;

require_once('Spreadsheet/Excel/Writer.php');


class MGReports_ExcelWriter extends Spreadsheet_Excel_Writer {
	
	private $workSheet;			/** The worksheet for the report */
	
	/**
	 * @param $args The arguments for the class constructor: (filename)
	 * */
	public function __construct($args = null){
		parent::Spreadsheet_Excel_Writer($args);
		
		$this->setTempDir(G_UPLOADPAH);
		$this->setVersion(8);

		$this->workSheet = &$this->addWorksheet('Report');
		$this->workSheet->setInputEncoding('utf-8');		
	}
	
	public function write() {
		
		
		$this->workSheet->close();
	}
}
?>